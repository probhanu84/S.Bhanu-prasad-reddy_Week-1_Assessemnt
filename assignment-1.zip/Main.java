
public class Main
{
	public static void main(String[] args) {
		int a= 10;
		int b= 5;
		int Addition = a+b;
		System.out.println(Addition);
		int Subtraction = a-b;
		System.out.println(Subtraction);
		int Multiplication = a*b;
		System.out.println(Multiplication);
		int Division = a/b;
		System.out.println(Division);
	}
}
